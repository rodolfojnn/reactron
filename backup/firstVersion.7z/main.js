require('electron-reload')(__dirname, {electron: require(`${__dirname}/node_modules/electron`)});
const { app, BrowserWindow } = require('electron')
const path = require('path')
const { ipcMain } = require('electron')
const { ipcMainConfig } = require('./ipcMain.service');

function createWindow () {
  const win = new BrowserWindow({
    width: 1200,
    height: 600,
    x: 2000,
    y: 100,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.loadFile('src/build/index.html')
  return win;
}

app.whenReady().then(() => {
  createWindow()
    .webContents.openDevTools()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

ipcMainConfig(ipcMain);