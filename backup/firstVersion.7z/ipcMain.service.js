var robot = require("robotjs");

exports.ipcMainConfig = (ipcMain) => {
  ipcMain.on('mouseMove', (event, arg) => {
    // Speed up the mouse.
    robot.setMouseDelay(2);

    var twoPI = Math.PI * 10;
    var screenSize = robot.getScreenSize();
    var height = (screenSize.height / 2) - 10;
    var width = screenSize.width;

    for (var x = 0; x < width; x = x + 5)
    {
      y = height * Math.sin((twoPI * x) / width) + height;
      robot.moveMouse(x, y);
    }

    event.returnValue = 'pong'
  })

  ipcMain.on('mouseColor', (event, arg) => {
    try {
      var mouse = robot.getMousePos();

      // Get pixel color in hex format.
      var hex = robot.getPixelColor(mouse.x, mouse.y);
      event.returnValue = {hex, mouse}
    } catch (error) {
      event.returnValue = error
    }

  })
}