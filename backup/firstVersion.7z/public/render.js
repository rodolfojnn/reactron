// https://www.electronjs.org/docs/api/ipc-main
const { ipcRenderer } = require('electron')

class Home {

  hists = {
    hist1Buy: '000',
    hist1Sell: '000',
    hist1Status: '000'
  }


  constructor() {
    console.log(123);
  }

  mouseMove() {
    console.log(ipcRenderer.sendSync('mouseMove')) // prints "pong"
  }

  mouseColor() {
    setInterval(() => {
      const ret = ipcRenderer.sendSync('mouseColor');
      document.querySelector('#color').style.background = '#' + ret.hex;
      console.log(ret);
    }, 1000);
  }

}
Home = new Home();